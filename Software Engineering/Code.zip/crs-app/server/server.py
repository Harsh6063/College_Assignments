import torch
from flask import Flask, request, jsonify
import pandas as pd
import networkx as nx
import torch.nn.functional as F
import numpy as np
from torch_geometric.data import Data
from torch_geometric.nn import SAGEConv

# Load the course dataset
course_dataset = pd.read_csv("try_file - Copy.csv")

# Initialize the graph
G = nx.Graph()

# Add nodes (courses) to the graph with attributes
for i in range(len(course_dataset['CourseID'])):
    G.add_node(course_dataset['CourseID'][i], name=course_dataset['course'][i], 
               skills=course_dataset['skills'][i], rating=course_dataset['rating'][i], 
               level=course_dataset['level'][i], certificate_type=course_dataset['certificatetype'][i], 
               duration=course_dataset['duration(Months)'][i])

# Add edges between courses based on their attributes (skills, level, rating, etc.)
for i in range(len(course_dataset['CourseID'])):
    for j in range(i + 1, len(course_dataset['CourseID'])):
        weight = 0
        if course_dataset['skills'][i] == course_dataset['skills'][j]:
            weight += 2
        if abs(course_dataset['level'][i] - course_dataset['level'][j]) <= 1:
            weight += 1
        if abs(course_dataset['rating'][i] - course_dataset['rating'][j]) <= 1:
            weight += 1
        if abs(course_dataset['certificatetype'][i] - course_dataset['certificatetype'][j]) <= 1:
            weight += 1
        if abs(course_dataset['duration(Months)'][i] - course_dataset['duration(Months)'][j]) <= 1:
            weight += 1
        if weight > 1:
            G.add_edge(course_dataset['CourseID'][i], course_dataset['CourseID'][j], weight=weight)

# Convert the graph into a format compatible with PyTorch Geometric
edge_index = torch.tensor(list(G.edges), dtype=torch.long).t().contiguous()

node_features = np.array([
    [G.nodes[n]['skills'], G.nodes[n]['level'], G.nodes[n]['rating'],
     G.nodes[n]['certificate_type'], G.nodes[n]['duration']]
    for n in G.nodes()
])

# Convert node features to a tensor
x = torch.tensor(node_features, dtype=torch.float)

# Prepare data for the model
data = Data(x=x, edge_index=edge_index)

# Define the GraphSAGE model
class GraphSAGE(torch.nn.Module):
    def __init__(self):
        super(GraphSAGE, self).__init__()
        self.conv1 = SAGEConv(data.num_node_features, 8)  # First layer, 8 hidden units
        self.conv2 = SAGEConv(8, 4)  # Second layer, 4 hidden units
        self.conv3 = SAGEConv(4, 2)  # Output layer, embedding into 2 dimensions

    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = self.conv2(x, edge_index)
        x = F.relu(x)
        x = self.conv3(x, edge_index)
        return x

# Initialize the model
model = GraphSAGE()

# Load the trained model
model.load_state_dict(torch.load("graph_sage_model.pth"))
model.eval()  # Set model to evaluation mode

# Flask setup
app = Flask(__name__)

import numpy as np

# Utility function to convert non-serializable types to native Python types
def convert_non_serializable(value):
    if isinstance(value, np.int64):  # Check for NumPy int64
        return int(value)  # Convert to Python int
    elif isinstance(value, np.float64):  # Check for NumPy float64
        return float(value)  # Convert to Python float
    elif isinstance(value, list):  # If it's a list, process each element
        return [convert_non_serializable(i) for i in value]
    elif isinstance(value, dict):  # If it's a dictionary, process each key-value pair
        return {k: convert_non_serializable(v) for k, v in value.items()}
    elif isinstance(value, torch.Tensor):  # For PyTorch tensors
        return value.cpu().numpy().tolist()  # Convert tensor to list
    return value  # Return value if it's already serializable

@app.route('/recommend', methods=['POST'])
def recommend_course():
    # Log the incoming request body to see the exact data being sent
    print(request.get_json())

    try:
        data = request.get_json()
        skill_value = int(data.get('skill_value'))
        level_value = int(data.get('level_value'))
        rating_value = float(data.get('rating_value'))
        cert_type_value = int(data.get('cert_type_value'))
        duration_value = int(data.get('duration_value'))
    except (TypeError, ValueError, KeyError) as e:
        return jsonify({"error": "Invalid input parameters"}), 400
    
    # Get the course embeddings after training
    with torch.no_grad():
        data = Data(x=x, edge_index=edge_index)  # Re-create the Data object here
        course_embeddings = model(data)  # Pass the Data object to the model

    # Find courses that match the given input parameters
    similar_courses = []
    for i, course_id in enumerate(G.nodes):
        course = G.nodes[course_id]
        similarity_score = 0
        if course['skills'] == skill_value:
            similarity_score += 2  # Skill match is important, so give it higher weight

        if abs(course['level'] - level_value) <= 1:
            similarity_score += 1  # Level match within a range

        if abs(course['rating'] - rating_value) <= 0.5:
            similarity_score += 1  # Rating match within a threshold

        if course['certificate_type'] == cert_type_value:
            similarity_score += 1  # Certificate type exact match

        if abs(course['duration'] - duration_value) <= 1:
            similarity_score += 1  # Duration match within a range

        # Convert embedding to a list of floats and ensure compatibility with JSON serialization
        embedding_list = course_embeddings[i].cpu().numpy().tolist()  # Convert tensor to a list

        # Add the course with its similarity score and embedding
        similar_courses.append((course_id, similarity_score, embedding_list))

    # Sort the similar courses by the similarity score
    similar_courses = sorted(similar_courses, key=lambda x: x[1], reverse=True)

    # Prepare the response with top 5 recommendations
    recommendations = []
    for course_id, score, embedding in similar_courses:  # Top 5
        recommendations.append({
            "course_id": course_id,
            "course_name": G.nodes[course_id]['name'],
            "similarity_score": score,  # similarity_score is now int (not int64)
            "embedding": embedding  # Include the embedding as a list of floats
        })

    # Convert the recommendations to ensure that no non-serializable types are present
    recommendations = [convert_non_serializable(rec) for rec in recommendations]

    return jsonify({"recommendations": recommendations})

if __name__ == '__main__':
    app.run(debug=True)
