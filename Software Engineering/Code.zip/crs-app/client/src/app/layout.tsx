import { Metadata } from "next";
import { Exo } from "next/font/google";
import localFont from "next/font/local";
import Navigation from "../components/Navigation";
import "./globals.css";

const exo = Exo({
  subsets: ["latin"],
  weight: ["400", "600", "700"], 
  variable: "--font-exo",
});

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});

const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "10 900",
});

export const metadata: Metadata = {
  title: "Course Recommendation App",
  description: "Course recommendation powered by Graph Neural Networks.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${exo.variable} antialiased`}
      >
        <Navigation />
        <div className="container mx-auto px-6 py-8 max-w-7xl">
          <main className="backdrop-blur-lg rounded-lg p-8">
            {/* <h1 className="text-4xl font-bold text-gray-800 mb-6 text-center"></h1> */}
            <p className="text-gray-600 text-lg mb-8 text-center">
              Empowering users with personalized course recommendations through
              advanced algorithms and data science.
            </p>

            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
