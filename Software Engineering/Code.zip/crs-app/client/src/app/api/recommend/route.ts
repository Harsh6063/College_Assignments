// app/api/recommend/route.ts
import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    // Parse incoming request data
    const data = await request.json();

    // Send POST request to Flask backend
    const response = await fetch('http://127.0.0.1:5000/recommend', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    // Handle the response from the Flask backend
    if (!response.ok) {
      return new NextResponse(
        JSON.stringify({ error: 'Error fetching recommendations from the backend' }),
        { status: 500 }
      );
    }

    const recommendations = await response.json();

    // Return the recommendations as a response
    return NextResponse.json({ recommendations: recommendations.recommendations });

  } catch (error) {
    console.error('Error in API route:', error);
    return new NextResponse(
      JSON.stringify({ error: 'Internal Server Error' }),
      { status: 500 }
    );
  }
}
