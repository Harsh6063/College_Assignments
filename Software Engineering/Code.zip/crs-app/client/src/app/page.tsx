"use client";

import { useState } from "react";
import RecommendationForm from "../components/RecommendationForm";
import RecommendationList from "../components/RecommendationList";

export default function Home() {
  const [recommendations, setRecommendations] = useState<any[]>([]);

  const handleRecommendations = (newRecommendations: any[]) => {
    setRecommendations(newRecommendations);
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-white p-6">
      <div className="w-full max-w-5xl bg-white rounded-lg p-8">
        {/* Recommendation Form */}
        <RecommendationForm onRecommend={handleRecommendations} />

        {/* Recommendation List */}
        {recommendations.length > 0 && (
          <RecommendationList recommendations={recommendations} />
        )}
      </div>
    </div>
  );
}
