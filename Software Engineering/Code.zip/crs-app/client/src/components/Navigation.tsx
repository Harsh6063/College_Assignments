"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";

const Navigation = () => {
  // State to track if the page is scrolled
  const [isScrolled, setIsScrolled] = useState(false);

  // Detect page scroll
  const handleScroll = () => {
    if (window.scrollY > 100) {
      setIsScrolled(true);
    } else {
      setIsScrolled(false);
    }
  };

  // Scroll to the top of the page
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Listen for scroll events
  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <nav className="bg-cyan-500 p-4 shadow-md sticky top-0 z-50">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-3xl font-bold text-white">Course Recommendation System</h1>
        <ul className="flex space-x-6 text-white">
          <li>
            <Link href="/" className="hover:text-blue-200 transition-colors">
              Home
            </Link>
          </li>
          <li>
            <Link href="/about" className="hover:text-blue-200 transition-colors">
              About
            </Link>
          </li>
        </ul>
      </div>

      {/* Scroll to Top Button */}
      {isScrolled && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-6 right-6 bg-cyan-500 text-white p-4 rounded-full shadow-2xl transform transition-all duration-300 hover:scale-110 hover:bg-blue-700 hover:shadow-2xl hover:animate-pulse focus:outline-none"
          title="Scroll to Top"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            className="w-6 h-6"
          >
            <path
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              d="M19 14l-7-7-7 7"
            />
          </svg>
        </button>
      )}
    </nav>
  );
};

export default Navigation;
