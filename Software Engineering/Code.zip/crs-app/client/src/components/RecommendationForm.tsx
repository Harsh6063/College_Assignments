"use client";

import { useState } from "react";

interface RecommendationFormProps {
  onRecommend: (recommendations: any[]) => void;
}

const RecommendationForm = ({ onRecommend }: RecommendationFormProps) => {
  const [skillValue, setSkillValue] = useState<number>(1);
  const [levelValue, setLevelValue] = useState<number>(1); 
  const [ratingValue, setRatingValue] = useState<number>(3.0);
  const [certTypeValue, setCertTypeValue] = useState<number>(1); 
  const [durationValue, setDurationValue] = useState<number>(6);

  const handleRecommend = async () => {
    const response = await fetch("/api/recommend", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        skill_value: skillValue,
        level_value: levelValue,
        rating_value: ratingValue,
        cert_type_value: certTypeValue,
        duration_value: durationValue,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      onRecommend(data.recommendations);
    } else {
      console.error("Failed to fetch recommendations");
    }
  };

  return (
    <div className="w-full max-w-5xl bg-white bg-opacity-60 backdrop-blur-lg shadow-lg rounded-lg p-8">
      <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        Provide Your Preferences to Get Personalized Course Recommendations
      </h2>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-6">
        {/* Skill */}
        {/* Skill */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Skill
          </label>
          <select
            className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={skillValue}
            onChange={(e) => setSkillValue(Number(e.target.value))}
          >
            <option value={1}>Network Security</option>
            <option value={2}>Data Analysis</option>
            <option value={3}>Project Management</option>
            <option value={4}>Digital Marketing</option>
            <option value={5}>Data Science</option>
            <option value={6}>UX Design</option>
            <option value={7}>Machine Learning</option>
            <option value={8}>DevOps</option>
            <option value={9}>Software Engineering</option>
            <option value={10}>Business Analytics</option>
            <option value={11}>Database</option>
            <option value={12}>Deep Learning</option>
            <option value={13}>AI</option>
            <option value={14}>Web Development</option>
            <option value={15}>Cloud Computing</option>
            <option value={16}>SQL</option>
            <option value={17}>Communication</option>
            <option value={18}>Accounting</option>
            <option value={19}>Computer Programming</option>
            <option value={20}>Mobile Development</option>
            <option value={21}>Graphic Design</option>
            <option value={22}>Operating Systems</option>
          </select>
        </div>

        {/* Level */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Level
          </label>
          <select
            className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={levelValue}
            onChange={(e) => setLevelValue(Number(e.target.value))}
          >
            <option value={1}>Beginner</option>
            <option value={2}>Intermediate</option>
            <option value={3}>Advanced</option>
          </select>
        </div>

        {/* Rating as a Scale */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Rating Value
          </label>
          <div className="flex items-center space-x-2">
            <span>0</span>
            <input
              type="range"
              min={0}
              max={5}
              step={0.1}
              value={ratingValue}
              onChange={(e) => setRatingValue(Number(e.target.value))}
              className="w-full accent-yellow-500" // Use Tailwind's 'accent' color for the slider
              style={{
                background: `linear-gradient(to right, gold ${
                  ratingValue * 20
                }%, #e5e7eb ${ratingValue * 20}%)`,
                appearance: "none",
                height: "8px",
                borderRadius: "5px",
                outline: "none",
              }}
            />
            <span>5</span>
          </div>
          <div className="text-center mt-2 text-yellow-600 font-bold">
            {ratingValue.toFixed(1)}
          </div>
        </div>

        {/* Certificate Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Certificate Type
          </label>
          <select
            className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={certTypeValue}
            onChange={(e) => setCertTypeValue(Number(e.target.value))}
          >
            <option value={1}>Course</option>
            <option value={2}>Specialization</option>
            <option value={3}>Professional</option>
          </select>
        </div>

        {/* Duration */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Duration
          </label>
          <select
            className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={durationValue}
            onChange={(e) => setDurationValue(Number(e.target.value))}
          >
            <option value={1}>1 Month</option>
            <option value={3}>3 Months</option>
            <option value={6}>6 Months</option>
          </select>
        </div>
      </div>

      {/* Submit Button */}
      <button
        onClick={handleRecommend}
        className="w-full py-3 bg-cyan-500 text-white font-semibold rounded-lg mt-6 hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-all"
      >
        Get Recommendations
      </button>
    </div>
  );
};

export default RecommendationForm;
