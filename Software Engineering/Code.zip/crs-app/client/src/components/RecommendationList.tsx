import React from 'react';

interface Recommendation {
  course_id: string;
  course_name: string;
  similarity_score: number;
  embedding: number[];
}

interface RecommendationListProps {
  recommendations: Recommendation[];
}

const RecommendationList = ({ recommendations }: RecommendationListProps) => {
  return (
    <div className="mt-8">
      <h2 className="text-xl font-semibold mb-4 text-gray-800">Recommended Courses</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {recommendations.slice(0, 5).map((rec) => (
          <div key={rec.course_id} className="bg-gray-50 p-4 rounded-md shadow-sm">
            <h3 className="text-lg font-semibold text-gray-900">{rec.course_name}</h3>
            <p className="text-gray-700">Similarity Score: {rec.similarity_score}</p>
            {/* <p className="text-gray-500">Embedding: {JSON.stringify(rec.embedding.slice(0, 5))}...</p> */}
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecommendationList;
